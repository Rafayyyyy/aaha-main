package com.example.aaha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
